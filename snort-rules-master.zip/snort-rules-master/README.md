
Snort.org Talos rules
==========
An UNOFFICIAL Git Repository of Snort Rules(R) Releases 
rules from https://snort.org

Emergingthreats rules
==========
rules from https://rules.emergingthreats.net/open/snort-2.9.0/

Abuse.ch rules
==========
rules from https://abuse.ch

Attack Detection from Positive Technologies
==========
rules from https://github.com/ptresearch/AttackDetection

Other rules
==========
https://osint.bambenekconsulting.com/feeds/c2-dommasterlist.txt  
https://security.etnetera.cz/feeds/etn_aggressive.rules  
https://rules.emergingthreats.net/open/suricata/rules/  
https://github.com/beave/sagan-rules/  

If you like this repo,please leave a star!
==========
## Stargazers over time

[![Stargazers over time](https://starchart.cc/codecat007/snort-rules.svg)](https://starchart.cc/codecat007/snort-rules)
